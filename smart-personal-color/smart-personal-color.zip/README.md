# SmartPersonalColor
An extension for MIT App Inventor 2.
Created by: Francisco Iago Lira Passos
Compiled by: FAST
