package com.iagolirapassos.smartpersonalcolor;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

@DesignerComponent(
        version = 16,
        versionName = "1.0",
        description = "AI Skin Tone Analyzer (ML Kit + KMeans + Subtom)",
        category = ComponentCategory.EXTENSION,
        nonVisible = true,
        iconName = "https://img.icons8.com/color/48/skin.png")
public class SmartPersonalColor extends AndroidNonvisibleComponent {

    private final ComponentContainer container;

    public SmartPersonalColor(ComponentContainer container) {
        super(container.$form());
        this.container = container;
    }

    @SimpleFunction(description = "Analyze image and get personal color info")
    public void Analyze(final String imagePath) {
        // Roda em background
        new Thread(new Runnable() {
            @Override
            public void run() {
                final java.util.Map<String, Object> result = analyzeSync(imagePath);
                container.$form().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (result == null) {
                            Error("Analysis failed");
                        } else {
                            AnalysisResult(
                                    (int) result.get("r"),
                                    (int) result.get("g"),
                                    (int) result.get("b"),
                                    (String) result.get("undertone"),
                                    (String) result.get("season"),
                                    (String) result.get("palette")
                            );
                        }
                    }
                });
            }
        }).start();
    }

    // Versão síncrona da análise
    private java.util.Map<String, Object> analyzeSync(String path) {
        try {
            if (path.startsWith("file://"))
                path = path.replace("file://", "");

            Bitmap original = BitmapFactory.decodeFile(path);
            if (original == null) return null;

            // Redimensiona
            Bitmap resized = Bitmap.createScaledBitmap(original, 480,
                    (int)((480.0/original.getWidth())*original.getHeight()), true);

            // Detecção de rosto
            InputImage image = InputImage.fromBitmap(resized, 0);

            FaceDetectorOptions options = 
                    new FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .build();

            FaceDetector detector = FaceDetection.getClient(options);

            java.util.concurrent.Semaphore sem = new java.util.concurrent.Semaphore(0);
            final java.util.List<Face> faceList = new ArrayList<>();

            detector.process(image)
                    .addOnSuccessListener(faces -> {
                        faceList.addAll(faces);
                        sem.release();
                    })
                    .addOnFailureListener(e -> sem.release());

            sem.acquire(); // Aguarda resultado

            if (faceList.isEmpty()) return null;

            Face face = faceList.get(0);
            Rect bounds = face.getBoundingBox();

            Bitmap faceBmp = Bitmap.createBitmap(
                    resized,
                    Math.max(bounds.left, 0),
                    Math.max(bounds.top, 0),
                    Math.min(bounds.width(), resized.getWidth()-bounds.left),
                    Math.min(bounds.height(), resized.getHeight()-bounds.top)
            );

            // Extrai pixels de pele
            java.util.List<int[]> skinPixels = extractSkinPixels(faceBmp);

            // Calcula dominante
            int[] dom = kMeans(skinPixels);

            return classify(dom);

        } catch (Exception e) {
            return null;
        }
    }

    // Pega pixels aleatórios que parecem pele
    private java.util.List<int[]> extractSkinPixels(Bitmap bmp) {
        java.util.List<int[]> list = new ArrayList<>();
        Random rand = new Random();

        for (int i = 0; i < 800; i++) {
            int x = rand.nextInt(bmp.getWidth());
            int y = rand.nextInt(bmp.getHeight());

            int px = bmp.getPixel(x, y);
            float[] hsv = new float[3];
            Color.RGBToHSV(Color.red(px), Color.green(px), Color.blue(px), hsv);

            if (hsv[0] >= 0 && hsv[0] <= 50 && hsv[1] >= 0.23 && hsv[1] <= 0.68) {
                list.add(new int[]{Color.red(px), Color.green(px), Color.blue(px)});
            }
        }
        return list;
    }

    // KMeans simples (centroide)
    private int[] kMeans(java.util.List<int[]> pixels) {
        if (pixels.isEmpty()) return new int[]{190,170,150};

        int sumR=0,sumG=0,sumB=0;
        for (int[] p : pixels) {
            sumR += p[0];
            sumG += p[1];
            sumB += p[2];
        }
        int n = pixels.size();
        return new int[]{sumR/n, sumG/n, sumB/n};
    }

    private java.util.Map<String, Object> classify(int[] rgb) {
        int r = rgb[0], g = rgb[1], b = rgb[2];

        // Subtom
        String undertone;
        int rgDiff = r - g;
        int gbDiff = g - b;
        if (rgDiff > 10) undertone = "Amarelado";
        else if (gbDiff > 10) undertone = "Rosado";
        else undertone = "Oliva";

        // HSV para estação
        float[] hsv = new float[3];
        Color.RGBToHSV(r,g,b,hsv);

        String season;
        if (hsv[2] > 0.62 && undertone.equals("Amarelado")) season = "Primavera";
        else if (hsv[2] > 0.62) season = "Verão";
        else if (undertone.equals("Amarelado")) season = "Outono";
        else season = "Inverno";

        String palette = generatePalette(r,g,b);

        java.util.Map<String,Object> map = new HashMap<>();
        map.put("r", r);
        map.put("g", g);
        map.put("b", b);
        map.put("undertone", undertone);
        map.put("season", season);
        map.put("palette", palette);

        return map;
    }

    private String generatePalette(int r,int g,int b){
        return "#" + Integer.toHexString(Color.rgb(r,g,b)).substring(2).toUpperCase();
    }

    @SimpleEvent(description = "Returns full analysis")
    public void AnalysisResult(int r, int g, int b,
                               String undertone,
                               String season,
                               String palette) {
        EventDispatcher.dispatchEvent(this, "AnalysisResult",
                r, g, b, undertone, season, palette);
    }

    @SimpleEvent(description = "Returns error message")
    public void Error(String msg) {
        EventDispatcher.dispatchEvent(this, "Error", msg);
    }
}
